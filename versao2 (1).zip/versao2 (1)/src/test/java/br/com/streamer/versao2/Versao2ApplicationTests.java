package br.com.streamer.versao2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Versao2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
